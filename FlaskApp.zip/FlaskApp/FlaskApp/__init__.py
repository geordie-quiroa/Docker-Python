from flask import Flask,render_template, url_for
import os, datetime, socket, netifaces
app = Flask(__name__)

@app.route('/')
@app.route('/whoami/')
def homepage():
        try:
            hostname = str(socket.getfqdn())
            date_of_requests = []
            sys_date = datetime.datetime.now()
            date_of_requests.append(str(sys_date))
            netifaces.ifaddresses('eth0')
            ip = netifaces.ifaddresses('eth0')[netifaces.AF_INET][0]['addr']
            return (render_template('whoami.html', hostname = hostname,  date_of_requests = date_of_requests, ip = ip))
        except Exception as e:
            return (str(e))

@app.route('/geordie/')

def geordie_page():
    try:
        texto = "Esta pagina utiliza Python (Flask -> flask, render_template [para pasar las variables  de python al html] y url_for [para facilitar los paths dentro del servidor]. Otras librerias de python --> os, datetime, socket y netifaces), Docker, html y Bootstrap. "
        return (render_template('geordie.html', texto = texto))
    except Exception as e:
        return (str(e))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
